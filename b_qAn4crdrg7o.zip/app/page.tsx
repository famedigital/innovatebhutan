"use client";

import { useState } from "react";
import { Navigation } from "@/components/navigation";
import { HeroSection } from "@/components/hero-section";
import { CategoryFilter } from "@/components/category-filter";
import { ServiceDirectory } from "@/components/service-directory";
import { StatsSection } from "@/components/stats-section";
import { BrandsSection } from "@/components/brands-section";
import { ContactSection } from "@/components/contact-section";
import { FooterSection } from "@/components/footer-section";
import { WhatsAppButton } from "@/components/whatsapp-button";

export default function HomePage() {
  const [activeCategory, setActiveCategory] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");

  return (
    <main className="min-h-screen bg-white">
      <Navigation />
      <HeroSection searchQuery={searchQuery} setSearchQuery={setSearchQuery} />
      <CategoryFilter activeCategory={activeCategory} setActiveCategory={setActiveCategory} />
      <ServiceDirectory activeCategory={activeCategory} searchQuery={searchQuery} />
      <StatsSection />
      <BrandsSection />
      <ContactSection />
      <FooterSection />
      <WhatsAppButton />
    </main>
  );
}

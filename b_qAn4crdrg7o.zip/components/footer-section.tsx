"use client";

import { motion } from "framer-motion";
import Link from "next/link";

const footerLinks = {
  services: {
    title: "Services",
    links: [
      { name: "POS Systems", href: "#services" },
      { name: "CCTV Solutions", href: "#services" },
      { name: "Biometric Access", href: "#services" },
      { name: "Hospitality Software", href: "#services" },
      { name: "Custom Development", href: "#services" },
    ]
  },
  brands: {
    title: "Brands",
    links: [
      { name: "Hikvision", href: "#brands" },
      { name: "ZKTeco", href: "#brands" },
      { name: "Rancelab", href: "#brands" },
      { name: "TYSSO", href: "#brands" },
      { name: "View All", href: "#brands" },
    ]
  },
  company: {
    title: "Company",
    links: [
      { name: "About Us", href: "#" },
      { name: "Our Team", href: "#" },
      { name: "Careers", href: "#" },
      { name: "Contact", href: "#contact" },
    ]
  },
  support: {
    title: "Support",
    links: [
      { name: "Help Center", href: "#" },
      { name: "Warranty", href: "#" },
      { name: "Service Request", href: "#" },
      { name: "WhatsApp Support", href: "https://wa.me/97517000000" },
    ]
  }
};

export function FooterSection() {
  return (
    <footer className="bg-[#030712] text-white">
      {/* Main Footer */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-8 lg:gap-12">
          {/* Brand Column */}
          <div className="col-span-2 md:col-span-4 lg:col-span-1 mb-8 lg:mb-0">
            <Link href="/" className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 bg-[#14532D] rounded-xl flex items-center justify-center">
                <span className="text-white font-bold text-lg">IB</span>
              </div>
              <div>
                <div className="text-lg font-semibold tracking-tight">INNOVATE</div>
                <div className="text-[10px] font-mono tracking-[0.2em] text-[#6B7280] -mt-0.5">BHUTAN</div>
              </div>
            </Link>
            <p className="text-sm text-[#9CA3AF] mb-6 max-w-xs">
              Bhutan&apos;s leading technology solutions provider. Delivering enterprise-grade systems since 2009.
            </p>
            <div className="flex items-center gap-3">
              {["FB", "IG", "LI"].map((social) => (
                <button
                  key={social}
                  className="w-9 h-9 bg-[#1F2937] rounded-lg flex items-center justify-center text-xs font-medium text-[#9CA3AF] hover:bg-[#14532D] hover:text-white transition-colors"
                >
                  {social}
                </button>
              ))}
            </div>
          </div>

          {/* Links Columns */}
          {Object.values(footerLinks).map((section) => (
            <div key={section.title}>
              <h4 className="text-sm font-semibold text-white mb-4">{section.title}</h4>
              <ul className="space-y-3">
                {section.links.map((link) => (
                  <li key={link.name}>
                    <Link
                      href={link.href}
                      className="text-sm text-[#9CA3AF] hover:text-white transition-colors"
                    >
                      {link.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-[#1F2937]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <p className="text-sm text-[#6B7280]">
              2024 Innovate Bhutan. All rights reserved.
            </p>
            <div className="flex items-center gap-6 text-sm text-[#6B7280]">
              <Link href="#" className="hover:text-white transition-colors">Privacy Policy</Link>
              <Link href="#" className="hover:text-white transition-colors">Terms of Service</Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}

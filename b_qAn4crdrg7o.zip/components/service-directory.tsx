"use client";

import { motion } from "framer-motion";
import { ArrowUpRight, MessageCircle, Star, CheckCircle2 } from "lucide-react";

const services = [
  {
    id: 1,
    name: "Point of Sale Systems",
    category: "pos",
    description: "Complete retail and restaurant POS solutions with inventory management, billing, and analytics.",
    features: ["Touch Screen Terminals", "Inventory Management", "Multi-branch Support", "Cloud Backup"],
    brands: ["TYSSO", "POSIFLEX", "Custom Solutions"],
    rating: 4.9,
    reviews: 124,
    popular: true,
    image: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=800&auto=format&fit=crop&q=60",
  },
  {
    id: 2,
    name: "CCTV & Surveillance",
    category: "security",
    description: "Professional grade security cameras with remote monitoring, night vision, and AI detection.",
    features: ["4K Resolution", "Night Vision", "Mobile App Access", "30-Day Storage"],
    brands: ["Hikvision", "Dahua", "Uniview"],
    rating: 4.8,
    reviews: 89,
    popular: true,
    image: "https://images.unsplash.com/photo-1557597774-9d273605dfa9?w=800&auto=format&fit=crop&q=60",
  },
  {
    id: 3,
    name: "Biometric Access Control",
    category: "biometric",
    description: "Fingerprint, face recognition, and card-based access systems for offices and facilities.",
    features: ["Face Recognition", "Fingerprint Scanner", "Attendance Tracking", "Door Integration"],
    brands: ["ZKTeco", "Hikvision", "Suprema"],
    rating: 4.7,
    reviews: 67,
    popular: false,
    image: "https://images.unsplash.com/photo-1558002038-1055907df827?w=800&auto=format&fit=crop&q=60",
  },
  {
    id: 4,
    name: "Rancelab Hotel Software",
    category: "hospitality",
    description: "Complete hotel management system with reservations, billing, housekeeping, and guest management.",
    features: ["Online Booking", "Room Management", "Restaurant POS", "Guest Portal"],
    brands: ["Rancelab"],
    rating: 4.9,
    reviews: 45,
    popular: true,
    image: "https://images.unsplash.com/photo-1566073771259-6a8506099945?w=800&auto=format&fit=crop&q=60",
  },
  {
    id: 5,
    name: "Custom Software Development",
    category: "software",
    description: "Bespoke web applications, mobile apps, and enterprise solutions tailored to your business needs.",
    features: ["Web Applications", "Mobile Apps", "API Integration", "Cloud Hosting"],
    brands: ["In-house Development"],
    rating: 5.0,
    reviews: 32,
    popular: false,
    image: "https://images.unsplash.com/photo-1461749280684-dccba630e2f6?w=800&auto=format&fit=crop&q=60",
  },
  {
    id: 6,
    name: "UPS & Inverter Systems",
    category: "power",
    description: "Reliable power backup solutions for homes, offices, and data centers with smart monitoring.",
    features: ["Pure Sine Wave", "Auto Transfer", "Battery Management", "Remote Monitoring"],
    brands: ["APC", "Luminous", "Microtek"],
    rating: 4.6,
    reviews: 78,
    popular: false,
    image: "https://images.unsplash.com/photo-1620714223084-8fcacc6dfd8d?w=800&auto=format&fit=crop&q=60",
  },
  {
    id: 7,
    name: "Network Infrastructure",
    category: "security",
    description: "Enterprise networking solutions including routers, switches, and structured cabling.",
    features: ["Gigabit Switching", "WiFi 6 Access Points", "Structured Cabling", "Network Security"],
    brands: ["Cisco", "TP-Link", "Ubiquiti"],
    rating: 4.8,
    reviews: 56,
    popular: false,
    image: "https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=800&auto=format&fit=crop&q=60",
  },
  {
    id: 8,
    name: "Restaurant POS & Kitchen Display",
    category: "pos",
    description: "Specialized POS for restaurants with table management, kitchen display, and online ordering.",
    features: ["Table Management", "Kitchen Display", "Online Orders", "Split Billing"],
    brands: ["Rancelab", "TYSSO", "Custom"],
    rating: 4.9,
    reviews: 93,
    popular: true,
    image: "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800&auto=format&fit=crop&q=60",
  },
];

interface ServiceDirectoryProps {
  activeCategory: string;
  searchQuery: string;
}

export function ServiceDirectory({ activeCategory, searchQuery }: ServiceDirectoryProps) {
  const filteredServices = services.filter((service) => {
    const matchesCategory = activeCategory === "all" || service.category === activeCategory;
    const matchesSearch = searchQuery === "" || 
      service.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      service.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      service.brands.some(b => b.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesCategory && matchesSearch;
  });

  return (
    <section id="products" className="py-16 bg-[#FAFAFA]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex items-center justify-between mb-10">
          <div>
            <h2 className="text-2xl sm:text-3xl font-semibold text-[#030712]">
              {activeCategory === "all" ? "All Services" : services.find(s => s.category === activeCategory)?.name || "Services"}
            </h2>
            <p className="text-[#6B7280] mt-1">{filteredServices.length} solutions available</p>
          </div>
        </div>

        {/* Service Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredServices.map((service, index) => (
            <motion.div
              key={service.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: index * 0.05 }}
              className="group bg-white rounded-2xl overflow-hidden card-elevated"
            >
              {/* Image */}
              <div className="relative h-48 overflow-hidden">
                <img
                  src={service.image}
                  alt={service.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                {service.popular && (
                  <div className="absolute top-4 left-4 px-3 py-1 bg-[#14532D] text-white text-xs font-medium rounded-full">
                    Popular
                  </div>
                )}
              </div>

              {/* Content */}
              <div className="p-6">
                {/* Rating */}
                <div className="flex items-center gap-2 mb-3">
                  <div className="flex items-center gap-1">
                    <Star className="w-4 h-4 fill-[#FBBF24] text-[#FBBF24]" />
                    <span className="text-sm font-medium text-[#030712]">{service.rating}</span>
                  </div>
                  <span className="text-sm text-[#6B7280]">({service.reviews} reviews)</span>
                </div>

                {/* Title */}
                <h3 className="text-lg font-semibold text-[#030712] mb-2 group-hover:text-[#14532D] transition-colors">
                  {service.name}
                </h3>

                {/* Description */}
                <p className="text-sm text-[#6B7280] mb-4 line-clamp-2">
                  {service.description}
                </p>

                {/* Features */}
                <div className="flex flex-wrap gap-2 mb-4">
                  {service.features.slice(0, 3).map((feature) => (
                    <span
                      key={feature}
                      className="inline-flex items-center gap-1 px-2 py-1 bg-[#F0FDF4] text-[#166534] text-xs rounded-md"
                    >
                      <CheckCircle2 className="w-3 h-3" />
                      {feature}
                    </span>
                  ))}
                </div>

                {/* Brands */}
                <div className="text-xs text-[#9CA3AF] mb-4">
                  Brands: {service.brands.join(", ")}
                </div>

                {/* Actions */}
                <div className="flex items-center gap-3">
                  <a
                    href={`https://wa.me/97517000000?text=Hi, I'm interested in ${encodeURIComponent(service.name)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex-1 inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-[#14532D] text-white text-sm font-medium rounded-xl hover:bg-[#166534] transition-colors"
                  >
                    <MessageCircle className="w-4 h-4" />
                    Get Quote
                  </a>
                  <button className="p-2.5 border border-[#E5E7EB] rounded-xl hover:bg-[#F3F4F6] transition-colors">
                    <ArrowUpRight className="w-4 h-4 text-[#6B7280]" />
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Empty State */}
        {filteredServices.length === 0 && (
          <div className="text-center py-20">
            <div className="w-16 h-16 bg-[#F3F4F6] rounded-full flex items-center justify-center mx-auto mb-4">
              <Search className="w-8 h-8 text-[#9CA3AF]" />
            </div>
            <h3 className="text-lg font-medium text-[#030712] mb-2">No services found</h3>
            <p className="text-[#6B7280]">Try adjusting your search or filter criteria</p>
          </div>
        )}
      </div>
    </section>
  );
}

function Search(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
      <circle cx="11" cy="11" r="8"/>
      <path d="m21 21-4.3-4.3"/>
    </svg>
  );
}

"use client";

import { motion } from "framer-motion";
import { 
  LayoutGrid, 
  Monitor, 
  ShieldCheck, 
  Fingerprint, 
  Hotel, 
  Code2, 
  Zap 
} from "lucide-react";

const categories = [
  { id: "all", name: "All Services", icon: LayoutGrid },
  { id: "pos", name: "POS Systems", icon: Monitor },
  { id: "security", name: "Security & CCTV", icon: ShieldCheck },
  { id: "biometric", name: "Biometric Access", icon: Fingerprint },
  { id: "hospitality", name: "Hospitality", icon: Hotel },
  { id: "software", name: "Software Dev", icon: Code2 },
  { id: "power", name: "Power Solutions", icon: Zap },
];

interface CategoryFilterProps {
  activeCategory: string;
  setActiveCategory: (category: string) => void;
}

export function CategoryFilter({ activeCategory, setActiveCategory }: CategoryFilterProps) {
  return (
    <section id="services" className="py-8 border-b border-[#E5E7EB] bg-white sticky top-[104px] z-40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-hide">
          {categories.map((category) => {
            const Icon = category.icon;
            const isActive = activeCategory === category.id;
            
            return (
              <motion.button
                key={category.id}
                onClick={() => setActiveCategory(category.id)}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className={`
                  flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium whitespace-nowrap transition-all duration-200
                  ${isActive 
                    ? "bg-[#14532D] text-white shadow-lg shadow-[#14532D]/20" 
                    : "bg-[#F3F4F6] text-[#374151] hover:bg-[#E5E7EB]"
                  }
                `}
              >
                <Icon className="w-4 h-4" />
                {category.name}
              </motion.button>
            );
          })}
        </div>
      </div>
    </section>
  );
}

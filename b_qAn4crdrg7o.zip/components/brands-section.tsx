"use client";

import { motion } from "framer-motion";

const brands = [
  { name: "Hikvision", category: "Security" },
  { name: "Dahua", category: "Security" },
  { name: "ZKTeco", category: "Biometric" },
  { name: "Rancelab", category: "Hospitality" },
  { name: "TYSSO", category: "POS" },
  { name: "POSIFLEX", category: "POS" },
  { name: "APC", category: "Power" },
  { name: "Cisco", category: "Network" },
  { name: "TP-Link", category: "Network" },
  { name: "Ubiquiti", category: "Network" },
  { name: "Luminous", category: "Power" },
  { name: "Suprema", category: "Biometric" },
];

export function BrandsSection() {
  return (
    <section id="brands" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <motion.span
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="text-sm font-medium text-[#16A34A] mb-2 block"
          >
            OFFICIAL PARTNERS
          </motion.span>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-3xl sm:text-4xl font-semibold text-[#030712] mb-4"
          >
            Brands We Represent
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-[#6B7280] max-w-2xl mx-auto"
          >
            Authorized distributor and service partner for leading global technology brands.
          </motion.p>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {brands.map((brand, index) => (
            <motion.div
              key={brand.name}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.05 }}
              whileHover={{ scale: 1.05, y: -4 }}
              className="bg-[#FAFAFA] border border-[#E5E7EB] rounded-xl p-6 text-center hover:border-[#BBF7D0] hover:bg-[#F0FDF4] transition-all duration-300 cursor-pointer"
            >
              <div className="text-lg font-semibold text-[#030712] mb-1">{brand.name}</div>
              <div className="text-xs text-[#9CA3AF]">{brand.category}</div>
            </motion.div>
          ))}
        </div>

        {/* Certification Badge */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mt-12 flex flex-col sm:flex-row items-center justify-center gap-6 p-6 bg-[#F0FDF4] rounded-2xl border border-[#BBF7D0]"
        >
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-[#14532D] rounded-full flex items-center justify-center">
              <svg className="w-6 h-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
              </svg>
            </div>
            <div>
              <div className="font-semibold text-[#030712]">Authorized Service Center</div>
              <div className="text-sm text-[#6B7280]">Certified technicians & genuine parts</div>
            </div>
          </div>
          <div className="hidden sm:block w-px h-12 bg-[#BBF7D0]" />
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-[#14532D] rounded-full flex items-center justify-center">
              <svg className="w-6 h-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <div>
              <div className="font-semibold text-[#030712]">Warranty Support</div>
              <div className="text-sm text-[#6B7280]">Up to 3 years manufacturer warranty</div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}

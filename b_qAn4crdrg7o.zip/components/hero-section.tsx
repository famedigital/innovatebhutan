"use client";

import { motion } from "framer-motion";
import { Search, ArrowRight, Sparkles } from "lucide-react";

interface HeroSectionProps {
  searchQuery: string;
  setSearchQuery: (query: string) => void;
}

export function HeroSection({ searchQuery, setSearchQuery }: HeroSectionProps) {
  const popularSearches = ["POS System", "CCTV Camera", "Biometric", "Hotel Software"];

  return (
    <section className="relative pt-32 pb-20 overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 dot-pattern opacity-50" />
      
      {/* Gradient Orbs */}
      <div className="absolute top-20 left-1/4 w-96 h-96 bg-[#DCFCE7] rounded-full blur-3xl opacity-40" />
      <div className="absolute bottom-0 right-1/4 w-80 h-80 bg-[#F0FDF4] rounded-full blur-3xl opacity-60" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-4xl mx-auto">
          {/* Badge */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="inline-flex items-center gap-2 px-4 py-2 bg-[#F0FDF4] border border-[#BBF7D0] rounded-full mb-8"
          >
            <Sparkles className="w-4 h-4 text-[#16A34A]" />
            <span className="text-sm font-medium text-[#166534]">Bhutan&apos;s Premier Tech Directory</span>
          </motion.div>

          {/* Headline */}
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="text-4xl sm:text-5xl lg:text-6xl font-semibold tracking-tight text-[#030712] mb-6"
          >
            Find the{" "}
            <span className="gradient-text">perfect technology</span>
            <br />
            solution for your business
          </motion.h1>

          {/* Subheadline */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="text-lg sm:text-xl text-[#6B7280] mb-10 max-w-2xl mx-auto"
          >
            POS systems, surveillance, biometric access, hospitality software, and enterprise solutions. 
            All from trusted brands, delivered across Bhutan.
          </motion.p>

          {/* Search Bar */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="max-w-2xl mx-auto mb-8"
          >
            <div className="relative group">
              <div className="absolute inset-0 bg-gradient-to-r from-[#22C55E] to-[#16A34A] rounded-2xl blur-xl opacity-20 group-hover:opacity-30 transition-opacity" />
              <div className="relative flex items-center bg-white rounded-2xl border border-[#E5E7EB] shadow-lg shadow-black/5 overflow-hidden">
                <Search className="w-5 h-5 text-[#9CA3AF] ml-5" />
                <input
                  type="text"
                  placeholder="Search for services, products, or brands..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="flex-1 px-4 py-5 text-base text-[#030712] placeholder:text-[#9CA3AF] focus:outline-none"
                />
                <button className="m-2 px-6 py-3 bg-[#14532D] text-white font-medium rounded-xl hover:bg-[#166534] transition-colors flex items-center gap-2">
                  Search
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </motion.div>

          {/* Popular Searches */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.4 }}
            className="flex flex-wrap items-center justify-center gap-2"
          >
            <span className="text-sm text-[#6B7280]">Popular:</span>
            {popularSearches.map((term) => (
              <button
                key={term}
                onClick={() => setSearchQuery(term)}
                className="px-3 py-1.5 text-sm text-[#374151] bg-[#F3F4F6] hover:bg-[#E5E7EB] rounded-lg transition-colors"
              >
                {term}
              </button>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  );
}
